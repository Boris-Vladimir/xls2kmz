Novidades da versão 2.0.4
	- Adicionados novos icones:
		 611 - Cepsa
		 612 - Galp
		 613 - Repsol
		 614 - Prio
		 615 - BP

		 619 - Túnel
		 620 - Início AE
		 621 - Fim AE
		 622 - Portagem eletrónica
		 623 - Portagem (Via verde, Com portageiro e Sem portageiro)
		 624 - Portagem (Via verde e Sem portageiro)
		 625 - Retirar tiquet de Portagem
		 626 - Via verde
		 627 - Sem portageiro
		 628 - Com portageiro
		 629 - Portagem (Com portageiro e Sem portageiro)
		 630 - Fronteira (Portugal)
		 631 - Parque de merendas
		 632 - Saída de Emergência
		 633 - Perigo Obras
		 634 - Radar fixo

		 700 - ASAE
		 701 - CTT
		 702 - AT
		 703 - Ascendi
		 704 - Brisa
		 705 - Ifraestruturas de Portugal
		 706 - Autoestradas Transmontanas
		 707 - Scutvias
		 708 - Norscut
		 709 - Autoestradas Douro
		 710 - Brisal
		 711 - Norte Litoral
		 712 - Via do Infante
		 713 - Autoestradas do Atlântico
		 714 - Autoestradas do Litoral Oeste
		 715 - Autoestradas Baixo Tejo

		 801 - Ponte
		 802 - Seta fina
		 803 - Seta grossa
		 804 - Seta dupla ponta
		 805 - Homem com alteres

		 987 - Homem a caminhar
		 988 - Carro desportivo
		 998 - Jeep

	- Adicionada a possiblidade de rodar (heading) os ícones:
		50, 106, 196, 222, 338, 350, 406, 496, 522, 802, 803, 804 e 1000 (ícone inexistente - qualquer ícone a que se dê o nome 1000, pode rodar)

	- Adicionado o parametro polygonamplitude
		- valor do ângulo da origem dos triângulos (células)
		- valores entre 0 e 180 ou 0 e -180 graus





